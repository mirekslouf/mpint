MPint = peak integration in multiple spectra
============================================

Description of data in this directory
-------------------------------------

* Three subdirectories (CZ, ES, IT) = data from (Czech Republic, Spain, Italy).
	- CZ datasets = standard two-column files
	- IT datasets = befor testing, install: `pip install pyspectra`
	- ES datasets = all-in-one file, preprocessing will unpack the spectra
* Each subdiretory = datafiles + scripts for a simple test of MPint package.
* Datafiles = here: IR spectra of UHMWPE; in general: arbitrary spectra.
* Scripts = PY-scripts, which use objects and functions defined in MPint.
* MPint calculation = calculation of specific peaks and indexes (OI, CI, VI).
* Description of peaks and indexes calculated in our case:
    - briefly: OI ~ oxidation, CI ~ crystallinity, VI ~ amount of C=C bonds
    - more in our publications:
      basics -
      [Fulin 2014](https://doi.org/10.1186/1471-2474-15-109);
      exact definitions - 
      [Slouf 2015](http://dx.doi.org/10.1016/j.polymertesting.2014.12.003)
    - the 1st publication is free,
      the 2nd available at request to corresponding author

How to test MPint calculations in this demo?
--------------------------------------------

* Go to each subdir, run PY-scripts (alphabetical order), and see results.
* The results are saved as files in active directory (TXT and PNG files).
* The scripts can be run from a command line or from Spyder (see below).

How to process further datasets?
--------------------------------
* Copy all spectra from a measured line scan to a separate directory.
	- The spectra must be numbered consecutively to get the correct results.
	- Note: ES-datasets = spectra in one DPT-file; pre-rocessing unpacks them.
* Copy the `000readme.txt` to this dir and modify it accordingly.
	- Our model data => brief-descriptions; real samples => SampleID necessary!
	- SampleID is a unique sample identifier that appears later in the database.
* Copy the `0*.py` files to this dir and run them.
	- There is either one file (just run) or two files (pre-process + run).
	- The scripts are laboratory-specific - use the correct script or adjust it!

Technical notes: running scripts from command line or Spyder
------------------------------------------------------------
* Technical notes:
	- Input  : datafiles and python scripts copied in a single directory.
	- Output : output spectra and profiles (TXT and PNG) in the same directory.
* Command line (or CLI, command shell):
	- In your command shell window, go to the directory with data and scripts.
	- Run the Python scripts (one or two scripts, depending on your dataset).
* Spyder (freeware Python IDE):
	- Drag and drop all Python scripts in selected directory to Spyder.
	- Run the Python scripts (one or two scripts, depending on your dataset).