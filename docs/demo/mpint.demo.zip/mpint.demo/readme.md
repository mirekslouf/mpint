MPint = peak integration in multiple spectra
============================================

Description of data in this directory
-------------------------------------

* Three subdirectories (CZ, ES, IT) = data from (Czech Republic, Spain, Italy).
* Each subdiretory = datafiles + scripts for a simple test of MPint package.
* Datafiles = here: IR spectra of UHMWPE; in general: arbitrary spectra.
* Scripts = PY-scripts, which use objects and functions defined in MPint.
* MPint calculation = calculation of specific peaks and indexes (OI, CI, VI).
* Description of peaks and indexes calculated in our case:
    - briefly: OI ~ oxidation, CI ~ crystallinity, VI ~ amount of C=C bonds
    - more in our publications:
      basics -
      [Fulin 2014](https://doi.org/10.1186/1471-2474-15-109);
      exact definitions - 
      [Slouf 2015](http://dx.doi.org/10.1016/j.polymertesting.2014.12.003)
    - the 1st publication is free,
      the 2nd available at request to corresponding author

How to test MPint calculations in this demo?
--------------------------------------------

* Go to each subdir, run PY-scripts (alphabetical order), and see results.
* The results are saved as files in active directory (TXT and PNG files).
* The scripts can be run from a command line or from Spyder (see below).

Technical notes concerning Spyder
---------------------------------

* Running scripts from a command line is quite Ok, but Spyder is recommended.
* Spyder is a freeware Python IDE (integrated development environment).
* Spyder installation is standard & easy - command line: `pip install spyder`.
* Spyder can be used also as UI (user interface):
    - This may be slightly non-standard, but it is very efficient.
    - Spyder enviromnent is well-established, stable, and user-friendly.
    - In Spyder you see program run, text and graphical outputs in one place.
