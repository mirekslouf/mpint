MPint calculation
2021-10-29 

Sample: UHMWPE cup, sample BOCAN, unworn surface, hexane delipidation  
Source: X:\2015-09-30\Z_UHMWPE.1\A78\SERIE.L\L1\A\01BOCAN\IR\2M.U\L01A01U1H
