'''
Rename SPC-files and convert them to DAT-files
Example: 46_1.spc => 46_001.spc => 46_001.dat
Reason: to get the files for future processing in the correct order
Note: the SPC-formatted files come from Italy/P.Bracco/mail:2019-10-17
'''

import re
import numpy as np
from pathlib import Path
from pyspectra.readers.read_spc import read_spc

# Define path
datafiles = Path('.').glob('*.[sS][pP][cC]')

# Prepare regular expression
# (filename MUST look like this: name_number.spc
re_filename = re.compile(r'(\S+)_(\d+)\.')

# Go through SPC-files, rename them and convert to DAT-files
# (renaming is necessary so that the files are in correct order in profiles
# (converting is done be an external package pyspectra
for datafile in datafiles:
    # (1) Save str-representation of given path
    # (note: this works well in Windows '\' is converted to '\\'
    # (result: in printing, we see single '\', in fact we have '\\'
    filename = str(datafile)
    # (2) Split filename to  m[1] = name and m[2] = number
    m = re.search(re_filename, filename)
    # (3) Use the saved integer in m[2] in replacement
    # (Example: Let us have s123_10.spc ...
    # (... we get m[1]='s123', m[2]='10'
    # (... and convert m[2] to '010', which should yield: s123_010.spc 
    m = re.sub(
         pattern = re_filename,
         repl    = f'{m[1]}' + '_' + f'{int(m[2]):03d}' + '.',
         string  = filename)
    # (4) Print datafile and its new name
    m = m.lower()
    print(datafile, '=>', m)
    # (5) Rename SPC-datafile
    datafile.rename(m)
    # (6) Final conversion of SPC to DAT
    # (...once the datafile name is correct so that the filenames are ordered
    # (...we can convert SPC-datafile to DAT-datafile
    spc = read_spc(m)
    data = np.array([spc.index.to_numpy(copy=True),spc.to_numpy(copy=True)])
    data = np.transpose(data)
    np.savetxt(m+'.dat', data, fmt=['%.1f', '%.6f'])
