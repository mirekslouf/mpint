'''
Rename SPC-files and convert them to DAT-files
Example: 46_1.spc => 46_001.spc => 46_001.dat
Reason: to get the files for future processing in the correct order
Note: the SPC-formatted files come from Italy/P.Bracco/mail:2019-10-17
'''

import re
import numpy as np
from pathlib import Path
from pyspectra.readers.read_spc import read_spc


# Define filenames
# (it reads all files *.spc or *.SPC
# (in Windows, glob ignores the case => glob('*.spc') is fine
# (for MacOS and Linux it is necessary to consider lowercase and uppercase
datafiles = Path('.').glob('*.[sS][pP][cC]')

# Prepare regular expression
# (filename = name_number.spc
re_filename = re.compile('(\S+)_(\d+)\.')

# Go through SPC-files, rename them and convert them to DAT-files
for datafile in datafiles:
    # Save str-representation of given path
    # (note: this works well in Windows '\' is converted to '\\'
    # (result: in printing, we see single '\', in fact we have '\\'
    filename = str(datafile)
    # Find the two last integers and save them in m[1] and m[2]
    m = re.search(re_filename, filename)
    # Use the saved integers in replacement
    m = re.sub(
         pattern = re_filename,
         repl    = f'{m[1]}' + '_' + f'{int(m[2]):03d}' + '.',
         string  = filename)
    # Print datafile and its new name
    m = m.lower()
    print(datafile, '=>', m)
    # Rename SPC-datafile
    datafile.rename(m)
    # Convert SPC-datafile to DAT-datafile
    spc = read_spc(m)
    data = np.array([spc.index.to_numpy(copy=True),spc.to_numpy(copy=True)])
    data = np.transpose(data)
    np.savetxt(m+'.dat', data, fmt=['%.1f', '%.6f'])


