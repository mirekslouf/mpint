'''
Convert DTP-file to DAT-files
Example: something.dpt => something_001.dat, something_002.dpt, ...
Reason: to get the files for future processing in the standard format
Note: the DPT-formatted files come from F.Medel/Spain/mail:2019-11-06
'''

import pandas as pd
from pathlib import Path


# Define DPT-datafile name
datafile = Path('./rhv005_back_inf.dpt')

# Read datafile to pandas dataframe
data = pd.read_csv('rhv005_back_inf.dpt', sep='\s+', header=None)

# Reverse the values in dataframe
# IMPORTANT: peak integration procedure needs wavelenght in ascending order!
data = data.reindex(index=data.index[::-1])

# Go through the columns of the datafile and save them as DAT-files
no_of_columns = len(data.columns)
for i in range (1,no_of_columns):
    output_filename = datafile.stem + f'_{i:03d}.dat'
    data.to_csv(
        output_filename,
        index=False, header=False, columns=([0,i]),
        sep=' ', float_format='%.5f')