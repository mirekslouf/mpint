"""
mpint
-----
Package for a simple peak integration in a XY-spectrum.
"""

# Package initialization file.
# (required for packing/distributing the directory as PY-package

__version__ = "1.0.0"