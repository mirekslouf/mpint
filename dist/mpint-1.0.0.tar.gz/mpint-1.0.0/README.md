## MPINT :: peak integration in multiple spectra

* The MPINT package **reads series of spectra**... <br>
  ...saves each spectrum as PNG image <br>
  ...**integrates peaks** defined by the user <br>
  ...**and calculates indexes** defined by the user.
* Explanation of key terms:
	* Series of spectra = set of XY-files (ascii files with two columns: X,Y)
	* User-defined peaks = peaks are defined by minimum and maximum X-values
	* User-defined indexes = indexes are defined as ratios between peak areas
	* Example: IR oxidation index = (area of C=O peak) / (area of standard peak)
* Simple user definition of peaks and indexes:
	* Both peaks and indexes are defined in a very simple PY-library.
	* Every user can easily create and/or modify its own libraries.
	* Once the library is defined, all calculations are fully automatic.
	* Sample library is 
	  [here](https://mirekslouf.github.io/mpint);
	  more detailed help can be found at
	  [Github](https://mirekslouf.github.io/mpint).
	
## Documentation, help, examples, demos...

* At the moment, all documentation is available at
  [Github](https://mirekslouf.github.io/mpint).
  
## Brief history

* Old versions of MPINT: Perl + GNUplot; work fine, not not too user-friendly 
* Version 1.0 = re-written in Python, tested on multiple files from CZ, IT, ES
