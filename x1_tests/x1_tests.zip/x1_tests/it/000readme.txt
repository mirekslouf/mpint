MPint calculation
2021-10-29 

Sample: UHMWPE liner, unknown testing sample from Italy/P.Bracco  
Source: mail:pc231;from:bracco;date:2019-10-17

