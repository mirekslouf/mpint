MPint calculation
2021-10-29 

Sample: UHMWPE liner, unknown testing sample from Spain/F.Medel  
Source: mail:pc231;from:medel;date:2019-11-06

